/**
 * 
 */
/**
 * @author core360
 *
 */
module javajdbcdesktop {
	
	requires java.desktop;
	requires java.sql;
	
}


package com.example.demo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	// reference to employee service interface
	private EmployeeService employeeService;

	// constructors
	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	// REST API endpoints
	// add new record
	// http://localhost:8080/api/employees/add
	@PostMapping("/api/employees/add")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){

		return new ResponseEntity<Employee>( 
				employeeService.saveEmployee(employee),
				HttpStatus.CREATED);
	
	};
	
	// get all records
	// http://localhost:8080/api/employees/all
	@GetMapping("/api/employees/all")
	public List<Employee> getAllEmployee(){
		return employeeService.getAllEmployees();
	}
	
	// get employee by id
	// http://localhost:8080/api/employees/3
	@GetMapping("/api/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") long employeeid){
		
		return new ResponseEntity<Employee>(
				employeeService.getEmployeeById(employeeid),
				HttpStatus.OK
				);
	}
	
	
	// update record
	// http://localhost:8080/api/employee/update/1
	@PutMapping("/api/employee/update/{id}")
	public ResponseEntity<Employee> updateEmployee(
			@PathVariable("id") long id,
			@RequestBody Employee employee
			){
		
		return new ResponseEntity<Employee>(
				employeeService.updateEmployee(employee, id),
				HttpStatus.OK
				);
		
	}
	
	
	
	// delete employee
	// http://localhost:8080/api/employees/delete/1
	@DeleteMapping("/api/employees/delete/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id){
		
		employeeService.deleteEmployee(id);
		return new ResponseEntity<String>(
				"Employee Record deleted", HttpStatus.OK
				);
		
	}
	
	


}

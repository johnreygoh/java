package com.example.demo;


public class AccountingFunctions {
	
	public int computeBasicSalary(int hours,int rateperhour) {
		return hours * rateperhour + 1000;
	}
	
	public int computeDeductions(int sss, int hdmf, int absences) {
		return sss + hdmf + absences;
	}
	
	public int computeNetPay(int basicsalary, int deductions) {
		return basicsalary - deductions;
	}
	
	

}

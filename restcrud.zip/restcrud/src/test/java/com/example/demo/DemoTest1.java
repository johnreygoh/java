package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DemoTest1 {

	AccountingFunctions af = new AccountingFunctions();
	
	@Test
	public void test_mystring() {
		
		String correctstring = "Today is Tuesday";
		String stringtocheck = "Today is Tuesday";
		assertEquals(correctstring, stringtocheck);
		
	}
	
	@Test
	public void test_computeBasicSalary() {
		assertEquals(2000, af.computeBasicSalary(1, 1000));
	}
	
	@Test
	public void test_computeDeduction() {
		assertEquals(900, af.computeDeductions(300, 300, 300));
	}
	
	@Test
	public void test_computeNetPay() {
		assertEquals(4900, af.computeNetPay(5000, 100));
	}
	
	
	
	
	
	
	
}

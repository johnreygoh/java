package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// spring annotation = class descriptions
// works similar to inheriting classes
@RestController
public class DemoController {
	
	// RESTful API
	// http://localhost:8080/hello
	// rest method? = GET
	@GetMapping("/hello")
	public String greetme() {
		return "hello pwc!";
	}
	
	// http://localhost:8080/employee
	// output = rizza santos
	@GetMapping("/employee")
	public Employee getEmployee(){
//		Employee e = new Employee();
//		e.setFirstName("rizza");
//		e.setLastName("santos");
//		e.setContactNo("234235");
		
//		Employee e = new Employee("rizza","santos","45454");
		return new Employee("joshua","garcia","23425");
		
	}
	
	// http://localhost:8080/getemployees
	// output = List of Employee
	@GetMapping("/getemployees")
	public List<Employee> getAllEmployees(){
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee("john","kong","345563"));
		employees.add(new Employee("angel","kang","756567"));
		employees.add(new Employee("henry","lamba","245563"));
		employees.add(new Employee("joseph","dino","3456645"));
		employees.add(new Employee("kelly","lombok","343667"));
		return employees;
		
	}
	
	// http://localhost:8080/employee/<firstname>/<lastname>/<contactno>
	// path variable(s)
	@GetMapping("/employee/{firstname}/{lastname}/{contactno}")
	public Employee employeePathVariable(
			@PathVariable("firstname") String fn,
			@PathVariable("lastname") String ln,
			@PathVariable("contactno") String cn) {
		
		return new Employee(fn,ln,cn);
		
	}
	
	// http://localhost:8080/employee/q?fn=ramon&ln=revill&cn=345346
	// query parameters
	@GetMapping("/employee/q")
	public Employee employeeQueryParams(
			@RequestParam("fn") String firstname,
			@RequestParam("ln") String lastname,
			@RequestParam("cn") String contactno
			) {
		
		return new Employee(firstname,lastname,contactno);
		
	}
	
	// http://localhost:8080/employee/cnp?ratehr=800&hrs=10&d=500
	// query params
	@GetMapping("/employee/cnp")
	public int computeNetPay(
			@RequestParam("ratehr") int ratehr,
			@RequestParam("hrs") int workhrs,
			@RequestParam("d") int deductions
			) {
		
		int netpay = (ratehr*workhrs)-deductions+1000;
		return netpay;
		
	}
	

}

package com.example.demo.service;

import com.example.demo.model.Employee;


public interface EmployeeService {
	
	// methods to add,update,get,delete records
	Employee saveEmployee(Employee employee);
	
}

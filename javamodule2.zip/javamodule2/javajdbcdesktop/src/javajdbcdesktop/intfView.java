package javajdbcdesktop;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class intfView extends JInternalFrame {
	private JTable table;
	private JTextField etxt_empid;
	private JTextField etxt_firstname;
	private JTextField etxt_lastname;
	private JTextField etxt_department;
	private JTextField etxt_position;
	private JTextField etxt_salary;
	private JTextField etxt_branch;
	private JButton btnSaveEdit;
	
	Cruddemo cdemo = new Cruddemo();
	DefaultTableModel d = new DefaultTableModel();
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					intfView frame = new intfView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	/**
	 * Create the frame.
	 */
	public intfView() {
		
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setTitle("View and update records");
		setBounds(100, 100, 746, 456);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 27, 666, 111);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnLoadEdit = new JButton("Load for editing");
		btnLoadEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//if more than record to edit
				//int numRows = table.getSelectedRows().length;
				//for(int i=0;i<numRows;i++) {}
				
				//if one record to edit
				etxt_empid.setText(d.getValueAt(table.getSelectedRow(), 0).toString());
				etxt_firstname.setText(d.getValueAt(table.getSelectedRow(), 1).toString());
				etxt_lastname.setText(d.getValueAt(table.getSelectedRow(), 2).toString());
				etxt_department.setText(d.getValueAt(table.getSelectedRow(), 3).toString());
				etxt_position.setText(d.getValueAt(table.getSelectedRow(), 4).toString());
				etxt_salary.setText(d.getValueAt(table.getSelectedRow(), 5).toString());
				etxt_branch.setText(d.getValueAt(table.getSelectedRow(), 6).toString());
				
				btnSaveEdit.setEnabled(true);
				
				
			}
		});
		btnLoadEdit.setBounds(473, 151, 221, 23);
		getContentPane().add(btnLoadEdit);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//show confirmation dialog
				int myconfirm = JOptionPane.showConfirmDialog(null, "sure to delete?"
																	,"Confirm Deletion"
																	,JOptionPane.YES_NO_OPTION
																	,JOptionPane.QUESTION_MESSAGE);
				
				if(myconfirm==JOptionPane.YES_OPTION) {
					
					String idToDelete = d.getValueAt(table.getSelectedRow(), 0).toString();
					String deletesql = "DELETE FROM employees2 where empid=" + idToDelete;
					
					try {
						cdemo.connect();
						cdemo.st.execute(deletesql);
						JOptionPane.showMessageDialog(null, "Record Deleted");
						d.removeRow(table.getSelectedRow());
						cdemo.disconnect();
						
					} catch (Exception e2) {
						JOptionPane.showMessageDialog(null, e.toString());
					}
									
					
				}else {
					JOptionPane.showMessageDialog(null, "Deletion Cancelled");
				}
				
				
				
			}
		});
		btnDelete.setBounds(473, 185, 221, 23);
		getContentPane().add(btnDelete);
		
		JLabel lblNewLabel = new JLabel("Emp ID");
		lblNewLabel.setBounds(28, 147, 69, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("First Name");
		lblNewLabel_1.setBounds(28, 172, 69, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Last Name");
		lblNewLabel_2.setBounds(28, 197, 69, 14);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Department");
		lblNewLabel_3.setBounds(28, 222, 69, 14);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Position");
		lblNewLabel_4.setBounds(28, 247, 69, 14);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Salary");
		lblNewLabel_5.setBounds(28, 272, 69, 14);
		getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Branch");
		lblNewLabel_6.setBounds(28, 297, 69, 14);
		getContentPane().add(lblNewLabel_6);
		
		etxt_empid = new JTextField();
		etxt_empid.setEditable(false);
		etxt_empid.setBounds(107, 144, 65, 20);
		getContentPane().add(etxt_empid);
		etxt_empid.setColumns(10);
		
		etxt_firstname = new JTextField();
		etxt_firstname.setBounds(107, 169, 322, 20);
		getContentPane().add(etxt_firstname);
		etxt_firstname.setColumns(10);
		
		etxt_lastname = new JTextField();
		etxt_lastname.setBounds(107, 194, 322, 20);
		getContentPane().add(etxt_lastname);
		etxt_lastname.setColumns(10);
		
		etxt_department = new JTextField();
		etxt_department.setBounds(107, 219, 322, 20);
		getContentPane().add(etxt_department);
		etxt_department.setColumns(10);
		
		etxt_position = new JTextField();
		etxt_position.setBounds(107, 244, 322, 20);
		getContentPane().add(etxt_position);
		etxt_position.setColumns(10);
		
		etxt_salary = new JTextField();
		etxt_salary.setBounds(107, 269, 322, 20);
		getContentPane().add(etxt_salary);
		etxt_salary.setColumns(10);
		
		etxt_branch = new JTextField();
		etxt_branch.setBounds(107, 294, 322, 20);
		getContentPane().add(etxt_branch);
		etxt_branch.setColumns(10);
		
		btnSaveEdit = new JButton("Save edits");
		btnSaveEdit.setEnabled(false);
		btnSaveEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String editid = etxt_empid.getText();
				String editfi = etxt_firstname.getText();
				String editla = etxt_lastname.getText();
				String editde = etxt_department.getText();
				String editpo = etxt_position.getText();
				String editsa = etxt_salary.getText();
				String editbr = etxt_branch.getText();
				
				String editsql = "update employees2 set "
						+ "firstname='" + editfi + "',"
						+ "lastname='" + editla + "',"
						+ "department='" + editde + "',"
						+ "position='" + editpo + "',"
						+ "salary=" + editsa + ","
						+ "branch='" + editbr + "' where empid=" + editid;
						
				try {
					
					cdemo.connect();
					cdemo.st.execute(editsql);
					JOptionPane.showMessageDialog(null, "Record updated");
					
					loadtable();
					
					etxt_empid.setText("");
					etxt_firstname.setText("");
					etxt_lastname.setText("");
					etxt_department.setText("");
					etxt_position.setText("");
					etxt_salary.setText("");
					etxt_branch.setText("");
					
					btnSaveEdit.setEnabled(false);
					
					cdemo.disconnect();
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e.toString());
				}
				
				
				
				
			}
		});
		btnSaveEdit.setBounds(246, 359, 180, 23);
		getContentPane().add(btnSaveEdit);
		
		JButton btnNewButton = new JButton("Reload Table");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				loadtable();
				
			}
		});
		btnNewButton.setBounds(527, 0, 167, 23);
		getContentPane().add(btnNewButton);
		
		loadtable();

	}//end of intfView constructor
	
	
	//method to load records to JTable
	public void loadtable() {
		
		try {
			
			cdemo.connect();
			
			String sql = "SELECT * FROM employees2";
			cdemo.rs = cdemo.st.executeQuery(sql);
			
			int i = 7; //how many columns for JTable
			
			d.setColumnCount(0);
			d.setRowCount(0);
			d.addColumn("Emp ID");
			d.addColumn("Firstname");
			d.addColumn("Lastname");
			d.addColumn("Department");
			d.addColumn("Position");
			d.addColumn("Salary");
			d.addColumn("Branch");
			table.setModel(d);
			
			//array
			String[] s = new String[i];
			while(cdemo.rs.next()) {
				s[0] = cdemo.rs.getString("empid").toString();
				s[1] = cdemo.rs.getString("firstname").toString();
				s[2] = cdemo.rs.getString("lastname").toString();
				s[3] = cdemo.rs.getString("department").toString();
				s[4] = cdemo.rs.getString("position").toString();
				s[5] = cdemo.rs.getString("salary").toString();
				s[6] = cdemo.rs.getString("branch").toString();
				d.addRow(s);
			}
						
			cdemo.disconnect();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.toString());
		}
				
	}//end of loadtable method
}//end of class

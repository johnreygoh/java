package com.example.demo;


public class Employee {
	
	private String firstName;
	private String lastName;
	private String contactNo;
	
	// add empty/default constructor
	public Employee() {
		super();
	}

	// add constructor for the properties
	public Employee(String firstName, String lastName, String contactNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
	}

	// getters and setters
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
}

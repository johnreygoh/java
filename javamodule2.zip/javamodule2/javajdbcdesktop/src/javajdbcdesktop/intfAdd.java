package javajdbcdesktop;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class intfAdd extends JInternalFrame {
	private JTextField txtfi;
	private JTextField txtla;
	private JTextField txtde;
	private JTextField txtpo;
	private JTextField txtsa;
	private JTextField txtbr;
	
	Cruddemo cdemo = new Cruddemo();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					intfAdd frame = new intfAdd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public intfAdd() {
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		setTitle("Add new record");
		setBounds(100, 100, 385, 307);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("First Name");
		lblNewLabel.setBounds(25, 62, 51, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Last Name");
		lblNewLabel_1.setBounds(25, 87, 50, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Department");
		lblNewLabel_2.setBounds(25, 113, 57, 14);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Position");
		lblNewLabel_3.setBounds(25, 138, 37, 14);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Salary");
		lblNewLabel_4.setBounds(25, 163, 30, 14);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Branch");
		lblNewLabel_5.setBounds(25, 188, 33, 14);
		getContentPane().add(lblNewLabel_5);
		
		txtfi = new JTextField();
		txtfi.setBounds(107, 59, 217, 20);
		getContentPane().add(txtfi);
		txtfi.setColumns(10);
		
		txtla = new JTextField();
		txtla.setBounds(107, 84, 217, 20);
		getContentPane().add(txtla);
		txtla.setColumns(10);
		
		txtde = new JTextField();
		txtde.setBounds(107, 110, 217, 20);
		getContentPane().add(txtde);
		txtde.setColumns(10);
		
		txtpo = new JTextField();
		txtpo.setBounds(107, 135, 217, 20);
		getContentPane().add(txtpo);
		txtpo.setColumns(10);
		
		txtsa = new JTextField();
		txtsa.setBounds(107, 160, 217, 20);
		getContentPane().add(txtsa);
		txtsa.setColumns(10);
		
		txtbr = new JTextField();
		txtbr.setBounds(107, 185, 217, 20);
		getContentPane().add(txtbr);
		txtbr.setColumns(10);
		
		JButton btnAdd = new JButton("Add Record");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String fi = txtfi.getText();
				String la = txtla.getText();
				String de = txtde.getText();
				String po = txtpo.getText();
				String sa = txtsa.getText();
				String br = txtbr.getText();
				
				String addsql = "INSERT INTO employees2 "
						+ "(firstname,lastname,department,position,salary,branch) "
						+ "values ('" + fi + "','" + la + "','" + de + "','" + po 
						+ "'," + sa + ",'" + br + "')";
				
				try {
					
					cdemo.connect();
					cdemo.st.execute(addsql);
					JOptionPane.showMessageDialog(null, "new record added");
					
					txtfi.setText("");
					txtla.setText("");
					txtde.setText("");
					txtpo.setText("");
					txtsa.setText("");
					txtbr.setText("");
					
					cdemo.disconnect();
					
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e.toString());
				}
				
			}
		});
		btnAdd.setBounds(234, 228, 89, 23);
		getContentPane().add(btnAdd);

	}

}

/**
 * 
 */
/**
 * @author core360
 *
 */
module javamysqlconsole {
	requires java.sql;
}